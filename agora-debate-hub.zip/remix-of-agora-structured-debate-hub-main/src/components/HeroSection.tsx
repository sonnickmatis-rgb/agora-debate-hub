import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { ArrowRight, Users, Timer, Gamepad2 } from "lucide-react";
import heroImage from "@/assets/hero-agora.jpg";

const features = [
  {
    icon: Users,
    title: "Débats Structurés",
    description: "Organisez des débats avec des formats éprouvés : Oxford, Lincoln-Douglas, Table Ronde ou libre.",
  },
  {
    icon: Timer,
    title: "Gestion du Temps",
    description: "Chronomètre intégré pour chaque intervenant. Temps de parole équitable et maîtrisé.",
  },
  {
    icon: Gamepad2,
    title: "Jeux Interactifs",
    description: "Votes rapides, quiz, avocat du diable… Dynamisez vos débats avec des activités engageantes.",
  },
];

export default function HeroSection() {
  return (
    <div className="relative">
      {/* Hero */}
      <section className="relative min-h-[85vh] overflow-hidden gradient-hero flex items-center">
        <div className="absolute inset-0">
          <img
            src={heroImage}
            alt="Agora - espace de débat"
            className="h-full w-full object-cover opacity-30 mix-blend-overlay"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-navy-deep/90 via-navy/60 to-transparent" />
        </div>

        <div className="container relative z-10 mx-auto px-4 py-24">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="mx-auto max-w-3xl text-center"
          >
            <h1 className="mb-4 font-display text-8xl font-bold tracking-tight text-sand md:text-9xl">
              Agora
            </h1>
            <p className="mb-10 text-lg leading-relaxed text-sand/70 md:text-xl max-w-xl mx-auto">
              Créez des débats, jouez à Mind, et engagez vos participants.
            </p>
            <div className="flex flex-col items-center gap-4 sm:flex-row sm:justify-center">
              <Button variant="hero" size="xl" asChild>
                <Link to="/debates/new">
                  Créer un débat
                  <ArrowRight className="h-5 w-5" />
                </Link>
              </Button>
              <Button variant="hero-outline" size="xl" asChild>
                <Link to="/debates">Voir les débats</Link>
              </Button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Features */}
      <section className="relative -mt-20 z-20 pb-20">
        <div className="container mx-auto px-4">
          <div className="grid gap-6 md:grid-cols-3">
            {features.map((feature, i) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5 + i * 0.15, duration: 0.5 }}
                className="group rounded-xl border border-border bg-card p-8 shadow-elevated transition-all hover:-translate-y-1 hover:shadow-warm"
              >
                <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
                  <feature.icon className="h-6 w-6 text-primary" />
                </div>
                <h3 className="mb-2 font-display text-xl font-semibold text-card-foreground">
                  {feature.title}
                </h3>
                <p className="text-sm leading-relaxed text-muted-foreground">
                  {feature.description}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
