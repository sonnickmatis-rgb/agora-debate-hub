import { Link, useLocation } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { Plus, Home, Brain, MessageSquare } from "lucide-react";

function AgoraLogo({ size = 36 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 36 36" fill="none" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <linearGradient id="logoGrad" x1="0" y1="0" x2="36" y2="36" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="hsl(16 65% 62%)" />
          <stop offset="100%" stopColor="hsl(28 80% 52%)" />
        </linearGradient>
        <filter id="logoGlow" x="-30%" y="-30%" width="160%" height="160%">
          <feGaussianBlur stdDeviation="2.5" result="blur" />
          <feComposite in="SourceGraphic" in2="blur" operator="over" />
        </filter>
      </defs>
      {/* Main bubble */}
      <rect x="3" y="3" width="22" height="17" rx="6" fill="url(#logoGrad)" />
      {/* Tail of main bubble */}
      <path d="M10 20 L7 26 L16 20Z" fill="url(#logoGrad)" />
      {/* Secondary bubble (offset, lighter) */}
      <rect x="13" y="13" width="20" height="14" rx="5" fill="hsl(16 65% 62% / 0.25)" stroke="hsl(16 65% 62% / 0.5)" strokeWidth="1.2" />
      {/* Tail of secondary bubble */}
      <path d="M26 27 L29 32 L22 27Z" fill="hsl(16 65% 62% / 0.25)" stroke="hsl(16 65% 62% / 0.4)" strokeWidth="0.8" />
      {/* Dots inside main bubble */}
      <circle cx="10" cy="11.5" r="1.5" fill="white" fillOpacity="0.9" />
      <circle cx="15" cy="11.5" r="1.5" fill="white" fillOpacity="0.9" />
      <circle cx="20" cy="11.5" r="1.5" fill="white" fillOpacity="0.9" />
    </svg>
  );
}

export default function Navbar() {
  const location = useLocation();
  const isHome = location.pathname === "/";

  return (
    <nav className="sticky top-0 z-50 border-b border-border bg-background/80 backdrop-blur-md">
      <div className="container mx-auto flex h-16 items-center justify-between px-4">
        <Link to="/" className="group flex items-center gap-2.5">
          <motion.div
            whileHover={{ scale: 1.08, rotate: -3 }}
            whileTap={{ scale: 0.95 }}
            transition={{ type: "spring", stiffness: 400, damping: 18 }}
            className="relative"
          >
            {/* glow ring on hover */}
            <div className="absolute inset-0 rounded-xl bg-primary/30 opacity-0 blur-md transition-opacity duration-300 group-hover:opacity-100" />
            <AgoraLogo size={36} />
          </motion.div>
          <span className="font-display text-xl font-bold tracking-tight text-foreground">
            Agora
          </span>
        </Link>

        <div className="flex items-center gap-2">
          {!isHome && (
            <Button variant="ghost" size="sm" asChild>
              <Link to="/">
                <Home className="h-4 w-4" />
                Accueil
              </Link>
            </Button>
          )}
          <Button variant="ghost" size="sm" asChild>
            <Link to="/debates">
              <MessageSquare className="h-4 w-4" />
              Débats
            </Link>
          </Button>
          <Button variant="ghost" size="sm" asChild>
            <Link to="/mind">
              <Brain className="h-4 w-4" />
              Mind
            </Link>
          </Button>
          <Button variant="warm" size="sm" asChild>
            <Link to="/debates/new">
              <Plus className="h-4 w-4" />
              Nouveau
            </Link>
          </Button>
        </div>
      </div>
    </nav>
  );
}
