import { useDebates } from "@/context/DebateContext";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import Navbar from "@/components/Navbar";
import { Plus, Users, Clock, Gamepad2 } from "lucide-react";
import { FORMAT_LABELS } from "@/types/debate";

const statusStyles: Record<string, string> = {
  draft: "bg-muted text-muted-foreground",
  active: "bg-olive/20 text-olive",
  completed: "bg-primary/15 text-primary",
};

const statusLabels: Record<string, string> = {
  draft: "Brouillon",
  active: "En cours",
  completed: "Terminé",
};

export default function DebateListPage() {
  const { debates } = useDebates();

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="container mx-auto px-4 py-12">
        <div className="mb-8 flex items-center justify-between">
          <div>
            <h1 className="font-display text-3xl font-bold text-foreground">Mes Débats</h1>
            <p className="mt-1 text-muted-foreground">Gérez et rejoignez vos débats</p>
          </div>
          <Button variant="warm" asChild>
            <Link to="/debates/new">
              <Plus className="h-4 w-4" />
              Nouveau débat
            </Link>
          </Button>
        </div>

        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {debates.map((debate, i) => (
            <motion.div
              key={debate.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.08 }}
            >
              <Link
                to={`/debates/${debate.id}`}
                className="group block rounded-xl border border-border bg-card p-6 shadow-card transition-all hover:-translate-y-0.5 hover:shadow-warm"
              >
                <div className="mb-3 flex items-center justify-between">
                  <Badge className={statusStyles[debate.status]}>{statusLabels[debate.status]}</Badge>
                  <span className="text-xs text-muted-foreground">{FORMAT_LABELS[debate.format]}</span>
                </div>
                <h3 className="mb-2 font-display text-lg font-semibold leading-snug text-card-foreground group-hover:text-primary transition-colors">
                  {debate.title}
                </h3>
                <p className="mb-4 text-sm text-muted-foreground line-clamp-2">{debate.description}</p>
                <div className="flex items-center gap-4 text-xs text-muted-foreground">
                  <span className="flex items-center gap-1">
                    <Users className="h-3.5 w-3.5" />
                    {debate.participants.length}/{debate.maxParticipants}
                  </span>
                  <span className="flex items-center gap-1">
                    <Clock className="h-3.5 w-3.5" />
                    {debate.speakingTime}s
                  </span>
                  {debate.games.length > 0 && (
                    <span className="flex items-center gap-1">
                      <Gamepad2 className="h-3.5 w-3.5" />
                      {debate.games.length} jeu{debate.games.length > 1 ? "x" : ""}
                    </span>
                  )}
                </div>
              </Link>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}
