import { Link } from "react-router-dom";
import { Plus, Brain, ArrowRight, Clock, Users, ChevronRight, Zap, Trophy } from "lucide-react";
import { motion } from "framer-motion";
import { useDebates } from "@/context/DebateContext";
import Navbar from "@/components/Navbar";
import { FORMAT_LABELS, DEBATE_CATEGORIES } from "@/types/debate";

const STATUS_CONFIG = {
  active:    { label: "En cours",  color: "text-emerald-400", bg: "bg-emerald-400/15 border-emerald-500/30", dot: "bg-emerald-400" },
  draft:     { label: "Brouillon", color: "text-muted-foreground", bg: "bg-muted/40 border-border", dot: "bg-muted-foreground/40" },
  completed: { label: "Terminé",   color: "text-sand/50",     bg: "bg-sand/5 border-sand/10",  dot: "bg-sand/30" },
};

const categoryIcon = (id?: string) =>
  DEBATE_CATEGORIES.find((c) => c.id === id)?.icon ?? "💬";

/* floating particle for hero */
function Particle({ x, y, delay, size }: { x: number; y: number; delay: number; size: number }) {
  return (
    <motion.div
      className="absolute rounded-full bg-primary/20 pointer-events-none"
      style={{ left: `${x}%`, top: `${y}%`, width: size, height: size }}
      animate={{ y: [0, -18, 0], opacity: [0.2, 0.6, 0.2] }}
      transition={{ duration: 3.5 + delay, repeat: Infinity, delay, ease: "easeInOut" }}
    />
  );
}

const PARTICLES = [
  { x: 8,  y: 25, delay: 0,    size: 5  },
  { x: 18, y: 65, delay: 0.8,  size: 3  },
  { x: 35, y: 15, delay: 1.4,  size: 4  },
  { x: 55, y: 70, delay: 0.3,  size: 6  },
  { x: 72, y: 30, delay: 1.9,  size: 3  },
  { x: 85, y: 60, delay: 0.6,  size: 5  },
  { x: 92, y: 20, delay: 1.2,  size: 4  },
  { x: 62, y: 80, delay: 2.1,  size: 3  },
];

export default function Index() {
  const { debates } = useDebates();

  const active    = debates.filter((d) => d.status === "active");
  const completed = debates.filter((d) => d.status === "completed");
  const recent    = debates.slice(0, 5);
  const totalPax  = debates.reduce((s, d) => s + d.participants.length, 0);

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      {/* ── HERO ── */}
      <div className="relative overflow-hidden">
        <div className="gradient-hero px-4 pb-20 pt-10 text-center">

          {/* particles */}
          {PARTICLES.map((p, i) => <Particle key={i} {...p} />)}

          {/* animated rings */}
          {[320, 460, 600].map((s, i) => (
            <motion.div
              key={s}
              className="pointer-events-none absolute inset-0 flex items-center justify-center"
              animate={{ rotate: i % 2 === 0 ? 360 : -360 }}
              transition={{ duration: 40 + i * 12, repeat: Infinity, ease: "linear" }}
            >
              <div
                className="rounded-full border border-white/5"
                style={{ width: s, height: s }}
              />
            </motion.div>
          ))}

          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.55 }}
            className="relative z-10"
          >
            {/* status pill */}
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.1, duration: 0.4 }}
              className="mb-4 inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-3.5 py-1.5 text-xs font-medium text-primary backdrop-blur-sm"
            >
              <span className="h-1.5 w-1.5 rounded-full bg-primary animate-pulse" />
              {active.length > 0
                ? `${active.length} débat${active.length > 1 ? "s" : ""} en cours`
                : "Prêt à débattre"}
            </motion.div>

            {/* title */}
            <h1 className="font-display text-6xl font-bold tracking-tight bg-gradient-to-br from-sand via-[hsl(28_80%_80%)] to-primary bg-clip-text text-transparent drop-shadow-[0_2px_32px_hsl(16_65%_55%/0.5)]">
              Agora
            </h1>
            <p className="mt-2 text-sand/45 text-sm tracking-wide">
              Organisez et animez vos débats
            </p>
          </motion.div>
        </div>

      </div>

      <main className="container mx-auto max-w-2xl px-4 pb-16 pt-20">

        {/* ── ACTION CARDS ── */}
        <motion.div
          initial={{ opacity: 0, y: 14 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3, duration: 0.45 }}
          className="mb-10 grid grid-cols-2 gap-3"
        >
          {/* New debate */}
          <Link
            to="/debates/new"
            className="group relative overflow-hidden rounded-2xl border border-primary/30 bg-card p-5 shadow-warm transition-all hover:-translate-y-1 hover:shadow-[0_10px_40px_-6px_hsl(16_65%_55%/0.35)]"
          >
            {/* bg blob */}
            <div className="absolute -right-8 -bottom-8 h-28 w-28 rounded-full bg-primary/10 transition-transform duration-500 group-hover:scale-150" />
            <div className="absolute -right-4 -bottom-4 h-16 w-16 rounded-full bg-primary/8 transition-transform duration-500 group-hover:scale-150" />

            <div className="relative">
              <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-xl gradient-warm shadow-warm">
                <Plus className="h-6 w-6 text-white" />
              </div>
              <p className="font-display text-lg font-bold text-foreground">Nouveau débat</p>
              <p className="mt-0.5 text-xs text-muted-foreground">Créer et configurer</p>
              <div className="mt-3 flex items-center gap-1 text-xs font-semibold text-primary transition-all duration-200 opacity-0 translate-x-[-4px] group-hover:opacity-100 group-hover:translate-x-0">
                Commencer <ArrowRight className="h-3.5 w-3.5" />
              </div>
            </div>
          </Link>

          {/* Mind game */}
          <Link
            to="/mind"
            className="group relative overflow-hidden rounded-2xl border border-border bg-card p-5 shadow-card transition-all hover:-translate-y-1 hover:border-primary/20 hover:shadow-warm"
          >
            <div className="absolute -right-8 -bottom-8 h-28 w-28 rounded-full bg-secondary/40 transition-transform duration-500 group-hover:scale-150" />
            <div className="absolute -right-4 -bottom-4 h-16 w-16 rounded-full bg-secondary/30 transition-transform duration-500 group-hover:scale-150" />

            <div className="relative">
              <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-xl bg-secondary">
                <Brain className="h-6 w-6 text-sand" />
              </div>
              <p className="font-display text-lg font-bold text-foreground">Jouer à Mind</p>
              <p className="mt-0.5 text-xs text-muted-foreground">Jeu de devinettes</p>
              <div className="mt-3 flex items-center gap-1 text-xs font-semibold text-muted-foreground transition-all duration-200 opacity-0 translate-x-[-4px] group-hover:opacity-100 group-hover:translate-x-0">
                Jouer <ArrowRight className="h-3.5 w-3.5" />
              </div>
            </div>
          </Link>
        </motion.div>

        {/* ── ACTIVE DEBATE ── */}
        {active.length > 0 && (
          <motion.section
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.38, duration: 0.4 }}
            className="mb-8"
          >
            <div className="mb-3 flex items-center gap-2">
              <Zap className="h-3.5 w-3.5 text-emerald-400" />
              <h2 className="text-xs font-bold uppercase tracking-widest text-emerald-400">En cours</h2>
            </div>
            <div className="space-y-2.5">
              {active.map((debate) => {
                const fill = Math.round((debate.participants.length / debate.maxParticipants) * 100);
                return (
                  <Link
                    key={debate.id}
                    to={`/debates/${debate.id}`}
                    className="group block rounded-2xl border border-emerald-500/25 bg-gradient-to-br from-emerald-500/8 to-transparent px-5 py-4 transition-all hover:-translate-y-0.5 hover:border-emerald-500/45 hover:shadow-[0_6px_24px_-4px_hsl(160_60%_40%/0.25)]"
                  >
                    <div className="flex items-center gap-3">
                      <span className="text-2xl">{categoryIcon(debate.category)}</span>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center justify-between gap-2">
                          <p className="truncate font-semibold text-foreground">{debate.title}</p>
                          <ChevronRight className="h-4 w-4 shrink-0 text-emerald-400 transition-transform group-hover:translate-x-0.5" />
                        </div>
                        <div className="mt-1 flex items-center gap-3 text-xs text-muted-foreground">
                          <span className="flex items-center gap-1"><Users className="h-3 w-3" />{debate.participants.length}/{debate.maxParticipants}</span>
                          <span className="flex items-center gap-1"><Clock className="h-3 w-3" />{debate.speakingTime}s</span>
                          <span>{FORMAT_LABELS[debate.format]}</span>
                        </div>
                      </div>
                    </div>
                    {/* participant fill bar */}
                    <div className="mt-3 h-1 w-full rounded-full bg-emerald-900/40">
                      <motion.div
                        className="h-1 rounded-full bg-emerald-400"
                        initial={{ width: 0 }}
                        animate={{ width: `${fill}%` }}
                        transition={{ delay: 0.5, duration: 0.7, ease: "easeOut" }}
                      />
                    </div>
                    <div className="mt-1 flex justify-between text-[10px] text-muted-foreground">
                      <span>{debate.participants.join(", ")}</span>
                      <span>{fill}% plein</span>
                    </div>
                  </Link>
                );
              })}
            </div>
          </motion.section>
        )}

        {/* ── RECENT DEBATES ── */}
        <motion.section
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.43, duration: 0.4 }}
        >
          <div className="mb-3 flex items-center justify-between">
            <h2 className="text-xs font-bold uppercase tracking-widest text-muted-foreground">Récents</h2>
            <Link to="/debates" className="flex items-center gap-1 text-xs text-muted-foreground transition-colors hover:text-primary">
              Voir tout <ArrowRight className="h-3 w-3" />
            </Link>
          </div>

          {recent.length === 0 ? (
            <div className="rounded-2xl border border-dashed border-border p-10 text-center text-sm text-muted-foreground">
              Aucun débat.{" "}
              <Link to="/debates/new" className="text-primary underline-offset-2 hover:underline">Créez-en un !</Link>
            </div>
          ) : (
            <ul className="space-y-2">
              {recent.map((debate, i) => {
                const st = STATUS_CONFIG[debate.status];
                return (
                  <motion.li
                    key={debate.id}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.48 + i * 0.07, duration: 0.35 }}
                  >
                    <Link
                      to={`/debates/${debate.id}`}
                      className="group flex items-center gap-3.5 rounded-xl border border-border bg-card px-4 py-3.5 shadow-card transition-all hover:-translate-y-0.5 hover:border-primary/20 hover:shadow-warm"
                    >
                      <span className="text-xl shrink-0">{categoryIcon(debate.category)}</span>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className={`inline-flex shrink-0 items-center gap-1.5 rounded-full border px-2 py-0.5 text-[11px] font-medium ${st.bg} ${st.color}`}>
                            <span className={`h-1.5 w-1.5 rounded-full shrink-0 ${st.dot}`} />
                            {st.label}
                          </span>
                          <span className="truncate text-sm font-medium text-foreground">{debate.title}</span>
                        </div>
                        <div className="mt-1 flex items-center gap-3 text-xs text-muted-foreground">
                          <span className="flex items-center gap-1"><Users className="h-3 w-3" />{debate.participants.length}/{debate.maxParticipants}</span>
                          <span className="flex items-center gap-1"><Clock className="h-3 w-3" />{debate.speakingTime}s</span>
                          <span>{FORMAT_LABELS[debate.format]}</span>
                        </div>
                      </div>
                      <ChevronRight className="h-4 w-4 shrink-0 text-border transition-all group-hover:translate-x-0.5 group-hover:text-muted-foreground" />
                    </Link>
                  </motion.li>
                );
              })}
            </ul>
          )}
        </motion.section>

        {/* ── COMPLETED BADGE ── */}
        {completed.length > 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.8, duration: 0.4 }}
            className="mt-8 flex items-center justify-center gap-2 text-xs text-muted-foreground"
          >
            <Trophy className="h-3.5 w-3.5" />
            {completed.length} débat{completed.length > 1 ? "s" : ""} terminé{completed.length > 1 ? "s" : ""}
          </motion.div>
        )}
      </main>
    </div>
  );
}
