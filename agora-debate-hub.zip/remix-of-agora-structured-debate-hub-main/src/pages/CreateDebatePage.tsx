import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { useDebates } from "@/context/DebateContext";
import Navbar from "@/components/Navbar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import {
  GAMES, GameType, Debate,
  FORMAT_INFO, FORMAT_LABELS,
  SUGGESTED_TOPICS, DEBATE_CATEGORIES,
  DEBATE_ROLES,
} from "@/types/debate";
import { ArrowLeft, Sparkles, Shuffle, PenLine, ListChecks, Shield, ChevronDown } from "lucide-react";

export default function CreateDebatePage() {
  const navigate = useNavigate();
  const { addDebate } = useDebates();

  const [topicMode, setTopicMode] = useState<"custom" | "suggested">("custom");
  const [title, setTitle] = useState("");
  const [category, setCategory] = useState("");
  const [format, setFormat] = useState<Debate["format"]>("table-ronde");
  const [speakingTime, setSpeakingTime] = useState(120);
  const [maxParticipants, setMaxParticipants] = useState(6);
  const [maxTimePerPerson, setMaxTimePerPerson] = useState(0);
  const [selectedGames, setSelectedGames] = useState<GameType[]>([]);
  const [selectedRoles, setSelectedRoles] = useState<string[]>([]);
  const [launching, setLaunching] = useState(false);

  const [rolesOpen, setRolesOpen] = useState(false);
  const [gamesOpen, setGamesOpen] = useState(false);

  const toggleGame = (game: GameType) =>
    setSelectedGames((p) => p.includes(game) ? p.filter((g) => g !== game) : [...p, game]);

  const toggleRole = (id: string) =>
    setSelectedRoles((p) => p.includes(id) ? p.filter((r) => r !== id) : [...p, id]);

  const filteredTopics = category
    ? SUGGESTED_TOPICS.filter((t) => t.category === category)
    : SUGGESTED_TOPICS;

  const pickRandom = () => {
    const pool = filteredTopics.filter((t) => t.topic !== title);
    const pick = pool[Math.floor(Math.random() * pool.length)];
    if (pick) { setTitle(pick.topic); setTopicMode("custom"); }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;
    const id = addDebate({
      title, description: "", category, format,
      speakingTime, maxParticipants, maxTimePerPerson: maxTimePerPerson || undefined,
      rules: [], games: selectedGames, roles: selectedRoles,
    });
    setLaunching(true);
    setTimeout(() => navigate(`/debates/${id}`), 650);
  };

  const fmtInfo = FORMAT_INFO[format];

  return (
    <div className="min-h-screen bg-background">
      <AnimatePresence>
        {launching && (
          <motion.div
            key="launch"
            initial={{ scale: 0, borderRadius: "50%", opacity: 1 }}
            animate={{ scale: 25, borderRadius: "0%", opacity: 1 }}
            transition={{ duration: 0.65, ease: [0.4, 0, 0.2, 1] }}
            className="fixed z-50 bg-[hsl(220_40%_8%)]"
            style={{ width: 120, height: 120, top: "50%", left: "50%", transform: "translate(-50%,-50%) scale(0)", transformOrigin: "center" }}
          />
        )}
      </AnimatePresence>
      <Navbar />
      <div className="container mx-auto max-w-2xl px-4 py-10">
        <Button variant="ghost" size="sm" className="mb-6" onClick={() => navigate(-1)}>
          <ArrowLeft className="h-4 w-4" /> Retour
        </Button>

        <h1 className="mb-8 font-display text-3xl font-bold text-foreground">Nouveau débat</h1>

        <form onSubmit={handleSubmit} className="space-y-10">

          {/* ── SUJET ── */}
          <section className="space-y-4">
            <Label className="text-base font-semibold">Sujet</Label>

            {/* Catégories */}
            <div className="flex flex-wrap gap-2">
              <button
                type="button"
                onClick={() => setCategory("")}
                className={`rounded-full border px-3 py-1 text-xs font-medium transition-all ${
                  category === ""
                    ? "border-primary bg-primary text-primary-foreground"
                    : "border-border bg-card text-muted-foreground hover:border-primary/40"
                }`}
              >
                Toutes
              </button>
              {DEBATE_CATEGORIES.map((cat) => (
                <button
                  key={cat.id}
                  type="button"
                  onClick={() => setCategory(cat.id === category ? "" : cat.id)}
                  className={`rounded-full border px-3 py-1 text-xs font-medium transition-all ${
                    category === cat.id
                      ? "border-primary bg-primary text-primary-foreground"
                      : "border-border bg-card text-muted-foreground hover:border-primary/40"
                  }`}
                >
                  {cat.icon} {cat.label}
                </button>
              ))}
            </div>

            {/* Mode toggle */}
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setTopicMode("custom")}
                className={`flex items-center gap-2 rounded-lg border px-4 py-2 text-sm font-medium transition-all ${
                  topicMode === "custom"
                    ? "border-primary bg-primary/10 text-primary"
                    : "border-border bg-card text-muted-foreground hover:border-primary/40"
                }`}
              >
                <PenLine className="h-4 w-4" /> Écrire mon sujet
              </button>
              <button
                type="button"
                onClick={() => setTopicMode("suggested")}
                className={`flex items-center gap-2 rounded-lg border px-4 py-2 text-sm font-medium transition-all ${
                  topicMode === "suggested"
                    ? "border-primary bg-primary/10 text-primary"
                    : "border-border bg-card text-muted-foreground hover:border-primary/40"
                }`}
              >
                <ListChecks className="h-4 w-4" /> Sujets proposés
              </button>
            </div>

            {topicMode === "custom" ? (
              <div className="flex gap-2">
                <Input
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="Ex : Le télétravail est-il bénéfique ?"
                  className="font-display text-base"
                  required
                />
                <Button type="button" variant="outline" size="icon" onClick={pickRandom} title="Sujet aléatoire">
                  <Shuffle className="h-4 w-4" />
                </Button>
              </div>
            ) : (
              <div className="grid gap-2 sm:grid-cols-2">
                {filteredTopics.length === 0 ? (
                  <p className="col-span-2 text-sm text-muted-foreground">Aucun sujet dans cette catégorie.</p>
                ) : filteredTopics.map(({ topic }) => (
                  <button
                    key={topic}
                    type="button"
                    onClick={() => { setTitle(topic); setTopicMode("custom"); }}
                    className={`rounded-lg border px-4 py-3 text-left text-sm transition-all hover:-translate-y-0.5 hover:shadow-warm ${
                      title === topic
                        ? "border-primary bg-primary/10 font-medium text-primary"
                        : "border-border bg-card text-foreground hover:border-primary/40"
                    }`}
                  >
                    {topic}
                  </button>
                ))}
              </div>
            )}
          </section>

          {/* ── FORMAT ── */}
          <section className="space-y-3">
            <Label className="text-base font-semibold">Format</Label>
            <div className="grid gap-3 sm:grid-cols-2">
              {(Object.entries(FORMAT_LABELS) as [Debate["format"], string][]).map(([val, label]) => {
                const info = FORMAT_INFO[val];
                const active = format === val;
                return (
                  <button
                    key={val}
                    type="button"
                    onClick={() => setFormat(val)}
                    className={`rounded-xl border p-4 text-left transition-all hover:-translate-y-0.5 ${
                      active
                        ? "border-primary bg-primary/5 shadow-warm"
                        : "border-border bg-card hover:border-primary/30"
                    }`}
                  >
                    <p className={`font-display font-semibold ${active ? "text-primary" : "text-foreground"}`}>
                      {label}
                    </p>
                    <p className={`mt-0.5 text-xs font-medium ${active ? "text-primary/70" : "text-muted-foreground"}`}>
                      {info.short}
                    </p>
                    <p className="mt-2 text-xs leading-relaxed text-muted-foreground">{info.detail}</p>
                  </button>
                );
              })}
            </div>
          </section>

          {/* ── TEMPS ── */}
          <div className="grid gap-6 sm:grid-cols-2">
            <div className="space-y-2">
              <Label>Temps de parole par tour</Label>
              <div className="flex items-center gap-3">
                <Input
                  type="number" min={30} max={600} step={30}
                  value={speakingTime}
                  onChange={(e) => setSpeakingTime(Number(e.target.value))}
                  className="w-28"
                />
                <span className="text-sm text-muted-foreground">
                  {speakingTime >= 60
                    ? `${Math.floor(speakingTime / 60)}min${speakingTime % 60 ? ` ${speakingTime % 60}s` : ""}`
                    : `${speakingTime}s`}
                </span>
              </div>
            </div>
            <div className="space-y-2">
              <Label>Temps max par personne</Label>
              <div className="flex items-center gap-3">
                <Input
                  type="number" min={0} max={3600} step={60}
                  value={maxTimePerPerson}
                  onChange={(e) => setMaxTimePerPerson(Number(e.target.value))}
                  className="w-28"
                  placeholder="0"
                />
                <span className="text-sm text-muted-foreground">
                  {maxTimePerPerson === 0
                    ? "illimité"
                    : maxTimePerPerson >= 60
                    ? `${Math.floor(maxTimePerPerson / 60)}min${maxTimePerPerson % 60 ? ` ${maxTimePerPerson % 60}s` : ""}`
                    : `${maxTimePerPerson}s`}
                </span>
              </div>
            </div>
          </div>

          {/* ── PARTICIPANTS ── */}
          <div className="space-y-2">
            <Label>Nombre max de participants</Label>
            <Input
              type="number" min={2} max={20}
              value={maxParticipants}
              onChange={(e) => setMaxParticipants(Number(e.target.value))}
              className="w-28"
            />
          </div>

          {/* ── RÔLES (optionnel) ── */}
          <section className="rounded-xl border border-border">
            <button
              type="button"
              onClick={() => setRolesOpen((o) => !o)}
              className="flex w-full items-center justify-between px-5 py-4 text-left"
            >
              <div className="flex items-center gap-2">
                <Shield className="h-4 w-4 text-primary" />
                <span className="font-semibold text-foreground">Rôles</span>
                <span className="rounded-full bg-muted px-2 py-0.5 text-xs text-muted-foreground">Optionnel</span>
                {selectedRoles.length > 0 && (
                  <span className="rounded-full bg-primary/15 px-2 py-0.5 text-xs font-medium text-primary">
                    {selectedRoles.length} sélectionné{selectedRoles.length > 1 ? "s" : ""}
                  </span>
                )}
              </div>
              <ChevronDown className={`h-4 w-4 text-muted-foreground transition-transform ${rolesOpen ? "rotate-180" : ""}`} />
            </button>

            {rolesOpen && (
              <div className="border-t border-border px-5 pb-5 pt-4 space-y-4">
                <p className="text-sm text-muted-foreground">
                  Chaque rôle a un pouvoir unique. Ils sont distribués <strong>aléatoirement</strong> aux participants au lancement.
                </p>
                <div className="grid gap-3 sm:grid-cols-2">
                  {DEBATE_ROLES.map((role) => {
                    const active = selectedRoles.includes(role.id);
                    return (
                      <label
                        key={role.id}
                        className={`flex cursor-pointer items-start gap-3 rounded-xl border p-4 transition-all hover:-translate-y-0.5 ${
                          active ? "border-primary bg-primary/5 shadow-warm" : "border-border bg-card hover:border-primary/30"
                        }`}
                      >
                        <Checkbox checked={active} onCheckedChange={() => toggleRole(role.id)} className="mt-0.5 shrink-0" />
                        <div className="min-w-0">
                          <div className="flex items-center gap-2">
                            <span className="text-lg">{role.icon}</span>
                            <span className="font-semibold text-card-foreground">{role.name}</span>
                          </div>
                          <span className={`mt-0.5 inline-block rounded-full px-2 py-0.5 text-xs font-medium ${
                            active ? "bg-primary/15 text-primary" : "bg-muted text-muted-foreground"
                          }`}>
                            {role.power}
                          </span>
                          <p className="mt-1.5 text-xs leading-relaxed text-muted-foreground">{role.detail}</p>
                        </div>
                      </label>
                    );
                  })}
                </div>
              </div>
            )}
          </section>

          {/* ── JEUX (optionnel) ── */}
          <section className="rounded-xl border border-border">
            <button
              type="button"
              onClick={() => setGamesOpen((o) => !o)}
              className="flex w-full items-center justify-between px-5 py-4 text-left"
            >
              <div className="flex items-center gap-2">
                <Sparkles className="h-4 w-4 text-[hsl(var(--gold))]" />
                <span className="font-semibold text-foreground">Jeux interactifs</span>
                <span className="rounded-full bg-muted px-2 py-0.5 text-xs text-muted-foreground">Optionnel</span>
                {selectedGames.length > 0 && (
                  <span className="rounded-full bg-primary/15 px-2 py-0.5 text-xs font-medium text-primary">
                    {selectedGames.length} sélectionné{selectedGames.length > 1 ? "s" : ""}
                  </span>
                )}
              </div>
              <ChevronDown className={`h-4 w-4 text-muted-foreground transition-transform ${gamesOpen ? "rotate-180" : ""}`} />
            </button>

            {gamesOpen && (
              <div className="border-t border-border px-5 pb-5 pt-4">
                <div className="grid gap-3 sm:grid-cols-2">
                  {GAMES.map((game) => (
                    <label
                      key={game.type}
                      className={`flex cursor-pointer items-start gap-3 rounded-xl border p-4 transition-all hover:-translate-y-0.5 ${
                        selectedGames.includes(game.type)
                          ? "border-primary bg-primary/5 shadow-warm"
                          : "border-border bg-card hover:border-primary/30"
                      }`}
                    >
                      <Checkbox
                        checked={selectedGames.includes(game.type)}
                        onCheckedChange={() => toggleGame(game.type)}
                        className="mt-0.5 shrink-0"
                      />
                      <div>
                        <div className="flex items-center gap-2">
                          <span>{game.icon}</span>
                          <span className="font-medium text-card-foreground">{game.label}</span>
                        </div>
                        <p className="mt-0.5 text-xs text-muted-foreground">{game.description}</p>
                      </div>
                    </label>
                  ))}
                </div>
              </div>
            )}
          </section>

          <Button
            type="submit"
            size="lg"
            className="w-full gradient-warm text-white hover:opacity-90"
            disabled={!title.trim()}
          >
            Créer le débat
          </Button>
        </form>
      </div>
    </div>
  );
}
