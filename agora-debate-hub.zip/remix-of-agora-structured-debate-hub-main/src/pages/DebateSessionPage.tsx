import { useState, useEffect, useCallback, useRef } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { useDebates } from "@/context/DebateContext";
import { FORMAT_LABELS, DEBATE_ROLES } from "@/types/debate";
import { ArrowLeft, Play, Pause, SkipForward, RotateCcw, Plus, X, Shuffle, Eye, ChevronRight, Minus, Flag, Trophy } from "lucide-react";

const formatTime = (s: number) => {
  const m = Math.floor(Math.abs(s) / 60);
  const sec = Math.abs(s) % 60;
  return `${s < 0 ? "-" : ""}${m}:${sec.toString().padStart(2, "0")}`;
};

function TimerRing({ value, max, size }: { value: number; max: number; size: number }) {
  const r = size / 2 - 8;
  const circ = 2 * Math.PI * r;
  const pct = Math.max(0, value / max);
  const isLow = value <= 10 && value > 0;
  return (
    <svg width={size} height={size} style={{ position: "absolute", inset: 0 }}>
      <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="hsl(220 30% 18%)" strokeWidth={6} />
      <circle
        cx={size / 2} cy={size / 2} r={r} fill="none"
        stroke={isLow ? "hsl(0 72% 51%)" : "hsl(16 65% 55%)"}
        strokeWidth={6} strokeLinecap="round"
        strokeDasharray={circ} strokeDashoffset={circ * (1 - pct)}
        transform={`rotate(-90 ${size / 2} ${size / 2})`}
        style={{ transition: "stroke-dashoffset 0.9s linear, stroke 0.3s" }}
      />
    </svg>
  );
}

function BudgetArc({ used, max, size = 64 }: { used: number; max: number; size?: number }) {
  const r = size / 2 - 3;
  const circ = 2 * Math.PI * r;
  const pct = Math.min(used / max, 1);
  const isOver = used >= max;
  return (
    <svg width={size} height={size} style={{ position: "absolute", inset: 0 }}>
      <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="hsl(220 30% 20%)" strokeWidth={3} />
      <circle
        cx={size / 2} cy={size / 2} r={r} fill="none"
        stroke={isOver ? "hsl(0 72% 51%)" : "hsl(45 80% 60%)"}
        strokeWidth={3} strokeLinecap="round"
        strokeDasharray={circ} strokeDashoffset={circ * (1 - pct)}
        transform={`rotate(-90 ${size / 2} ${size / 2})`}
        style={{ transition: "stroke-dashoffset 0.9s linear" }}
      />
    </svg>
  );
}

// +/- stepper for time values
function TimeStepper({ value, onChange, step = 30, min = 0, label }: {
  value: number; onChange: (v: number) => void; step?: number; min?: number; label: string;
}) {
  return (
    <div className="space-y-1.5">
      <p className="text-xs text-white/40 text-center">{label}</p>
      <div className="flex items-center gap-2">
        <button
          type="button"
          onClick={() => onChange(Math.max(min, value - step))}
          className="flex h-8 w-8 items-center justify-center rounded-lg bg-white/8 text-white/50 hover:bg-white/15 hover:text-white transition-all"
        >
          <Minus className="h-3.5 w-3.5" />
        </button>
        <div className="w-20 text-center">
          <span className="font-display text-lg font-semibold text-white tabular-nums">
            {value === 0 ? "∞" : formatTime(value)}
          </span>
        </div>
        <button
          type="button"
          onClick={() => onChange(value + step)}
          className="flex h-8 w-8 items-center justify-center rounded-lg bg-white/8 text-white/50 hover:bg-white/15 hover:text-white transition-all"
        >
          <Plus className="h-3.5 w-3.5" />
        </button>
      </div>
    </div>
  );
}

export default function DebateSessionPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { debates } = useDebates();
  const debate = debates.find((d) => d.id === id);

  const [phase, setPhase] = useState<"setup" | "roles" | "debate" | "vote" | "results">("setup");
  const [participants, setParticipants] = useState<string[]>(debate?.participants ?? []);
  const [nameInput, setNameInput] = useState("");

  // Local time settings (editable in setup)
  const [speakingTime, setSpeakingTime] = useState(debate?.speakingTime ?? 120);
  const [maxPerPerson, setMaxPerPerson] = useState(debate?.maxTimePerPerson ?? 0);

  // Debate state
  const [currentSpeaker, setCurrentSpeaker] = useState(0);
  const [timeLeft, setTimeLeft] = useState(debate?.speakingTime ?? 120);
  const [isRunning, setIsRunning] = useState(false);
  const [budgets, setBudgets] = useState<Record<string, number>>({});
  const [assignedRoles, setAssignedRoles] = useState<Record<string, string>>({});

  // Role reveal state
  const [revealIndex, setRevealIndex] = useState(0);
  const [roleRevealed, setRoleRevealed] = useState(false);

  // Vote state
  const [voteIndex, setVoteIndex] = useState(0);
  const [voteRevealed, setVoteRevealed] = useState(false);
  const [selectedVote, setSelectedVote] = useState<string | null>(null);
  const [votes, setVotes] = useState<Record<string, number>>({});

  const [tableSize, setTableSize] = useState(420);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const update = () => setTableSize(Math.min(420, window.innerWidth - 32));
    update();
    window.addEventListener("resize", update);
    return () => window.removeEventListener("resize", update);
  }, []);

  // If debate already has participants, jump to debate phase
  useEffect(() => {
    if (debate?.participants?.length && debate.participants.length >= 2) {
      setParticipants(debate.participants);
      const b: Record<string, number> = {};
      debate.participants.forEach((p) => (b[p] = 0));
      setBudgets(b);
      setPhase("debate");
    }
  }, []);

  // Timer tick
  useEffect(() => {
    if (!isRunning || timeLeft <= 0) return;
    const iv = setInterval(() => {
      setTimeLeft((t) => t - 1);
      if (maxPerPerson > 0) {
        setBudgets((prev) => ({
          ...prev,
          [participants[currentSpeaker]]: (prev[participants[currentSpeaker]] ?? 0) + 1,
        }));
      }
    }, 1000);
    return () => clearInterval(iv);
  }, [isRunning, timeLeft, currentSpeaker, participants, maxPerPerson]);

  useEffect(() => { if (timeLeft === 0) setIsRunning(false); }, [timeLeft]);

  const nextSpeaker = useCallback(() => {
    setCurrentSpeaker((s) => (s + 1) % participants.length);
    setTimeLeft(speakingTime);
    setIsRunning(false);
  }, [participants.length, speakingTime]);

  const addParticipant = () => {
    const t = nameInput.trim();
    if (t && !participants.includes(t)) { setParticipants((p) => [...p, t]); setNameInput(""); }
  };

  const assignRoles = (parts: string[]): Record<string, string> => {
    if (!debate?.roles?.length) return {};
    const shuffled = [...debate.roles].sort(() => Math.random() - 0.5);
    const map: Record<string, string> = {};
    parts.forEach((p, i) => { if (shuffled[i]) map[p] = shuffled[i]; });
    return map;
  };

  const goFromSetup = () => {
    if (participants.length < 2) return;
    const b: Record<string, number> = {};
    participants.forEach((p) => (b[p] = 0));
    setBudgets(b);
    setTimeLeft(speakingTime);
    const roles = assignRoles(participants);
    setAssignedRoles(roles);
    // Only go through role reveal if there are roles
    if (Object.keys(roles).length > 0) {
      setRevealIndex(0);
      setRoleRevealed(false);
      setPhase("roles");
    } else {
      setPhase("debate");
    }
  };

  const advanceReveal = () => {
    if (!roleRevealed) { setRoleRevealed(true); return; }
    if (revealIndex + 1 < participants.length) {
      setRevealIndex((i) => i + 1);
      setRoleRevealed(false);
    } else {
      setPhase("debate");
    }
  };

  const endDebate = () => {
    setIsRunning(false);
    const initial: Record<string, number> = {};
    participants.forEach((p) => (initial[p] = 0));
    setVotes(initial);
    setVoteIndex(0);
    setVoteRevealed(false);
    setSelectedVote(null);
    setPhase("vote");
  };

  const confirmVote = () => {
    if (!selectedVote) return;
    setVotes((prev) => ({ ...prev, [selectedVote]: (prev[selectedVote] ?? 0) + 1 }));
    if (voteIndex + 1 < participants.length) {
      setVoteIndex((i) => i + 1);
      setVoteRevealed(false);
      setSelectedVote(null);
    } else {
      setPhase("results");
    }
  };

  if (!debate) {
    return (
      <div className="min-h-screen bg-[hsl(220_40%_8%)] flex items-center justify-center">
        <p className="text-white/40">Débat introuvable</p>
      </div>
    );
  }

  const BG = "radial-gradient(ellipse at 50% 100%, hsl(220 35% 14%), hsl(220 40% 6%))";

  // ── SETUP ────────────────────────────────────────────────────────────────
  if (phase === "setup") {
    return (
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}
        className="min-h-screen flex flex-col items-center justify-center px-4 py-10"
        style={{ background: BG }}
      >
        <button onClick={() => navigate("/debates")}
          className="absolute top-5 left-5 flex items-center gap-1.5 text-sm text-white/40 hover:text-white/70 transition-colors">
          <ArrowLeft className="h-4 w-4" /> Retour
        </button>

        <div className="w-full max-w-sm space-y-5">
          <div className="text-center">
            <p className="text-xs uppercase tracking-widest text-white/30 mb-2">{FORMAT_LABELS[debate.format]}</p>
            <h1 className="font-display text-2xl font-bold text-white leading-snug">{debate.title}</h1>
          </div>

          {/* Time settings */}
          <div className="rounded-2xl border border-white/10 bg-white/5 p-5 backdrop-blur">
            <p className="text-sm font-medium text-white/70 mb-4">Paramètres de temps</p>
            <div className="flex items-start justify-around gap-4">
              <TimeStepper
                label="Par tour"
                value={speakingTime}
                onChange={setSpeakingTime}
                step={30}
                min={30}
              />
              <div className="w-px self-stretch bg-white/10" />
              <TimeStepper
                label="Max par personne"
                value={maxPerPerson}
                onChange={setMaxPerPerson}
                step={60}
                min={0}
              />
            </div>
            {maxPerPerson > 0 && maxPerPerson < speakingTime && (
              <p className="mt-3 text-center text-xs text-amber-400/70">
                ⚠ Le max par personne est inférieur au temps par tour
              </p>
            )}
          </div>

          {/* Participants */}
          <div className="rounded-2xl border border-white/10 bg-white/5 p-5 space-y-3 backdrop-blur">
            <p className="text-sm font-medium text-white/70">Participants</p>
            <div className="flex gap-2">
              <input
                value={nameInput}
                onChange={(e) => setNameInput(e.target.value)}
                onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); addParticipant(); } }}
                placeholder="Prénom ou pseudo…"
                className="flex-1 rounded-xl border border-white/10 bg-white/5 px-3 py-2.5 text-sm text-white placeholder:text-white/25 outline-none focus:border-white/30 transition-colors"
              />
              <button type="button" onClick={addParticipant} disabled={!nameInput.trim()}
                className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary text-white disabled:opacity-30 hover:opacity-90 transition-opacity">
                <Plus className="h-4 w-4" />
              </button>
            </div>

            <AnimatePresence>
              {participants.length > 0 && (
                <motion.ul className="space-y-2" initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
                  {participants.map((p, i) => (
                    <motion.li key={p}
                      initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, x: -20 }}
                      className="flex items-center justify-between rounded-xl bg-white/5 px-3 py-2.5"
                    >
                      <div className="flex items-center gap-2.5">
                        <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary/20 text-xs font-bold text-primary">
                          {p[0]?.toUpperCase()}
                        </div>
                        <span className="text-sm text-white">{p}</span>
                      </div>
                      <button onClick={() => setParticipants((prev) => prev.filter((_, idx) => idx !== i))}
                        className="text-white/20 hover:text-red-400 transition-colors">
                        <X className="h-4 w-4" />
                      </button>
                    </motion.li>
                  ))}
                </motion.ul>
              )}
            </AnimatePresence>
          </div>

          <motion.button onClick={goFromSetup} disabled={participants.length < 2}
            whileHover={{ scale: participants.length >= 2 ? 1.02 : 1 }} whileTap={{ scale: 0.98 }}
            className="w-full rounded-xl py-4 text-base font-semibold text-white transition-opacity disabled:opacity-30"
            style={{ background: "linear-gradient(135deg, hsl(16 65% 55%), hsl(45 80% 60%))" }}
          >
            {participants.length < 2
              ? `Ajoutez encore ${2 - participants.length} participant${participants.length === 0 ? "s" : ""}`
              : debate.roles?.length ? "Révéler les rôles →" : "Lancer le débat →"}
          </motion.button>
        </div>
      </motion.div>
    );
  }

  // ── ROLE REVEAL ──────────────────────────────────────────────────────────
  if (phase === "roles") {
    const currentPlayer = participants[revealIndex];
    const roleId = assignedRoles[currentPlayer];
    const role = DEBATE_ROLES.find((r) => r.id === roleId);
    const isLast = revealIndex === participants.length - 1;

    return (
      <motion.div
        key={`reveal-${revealIndex}-${roleRevealed}`}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="min-h-screen flex flex-col items-center justify-center px-6 text-center"
        style={{ background: BG }}
      >
        <AnimatePresence mode="wait">
          {!roleRevealed ? (
            /* Handoff screen */
            <motion.div key="handoff" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }}
              className="space-y-8 max-w-xs"
            >
              <div>
                <p className="text-white/30 text-sm mb-3">
                  {revealIndex + 1} / {participants.length}
                </p>
                <p className="text-white/50 text-base mb-2">Passe l'appareil à</p>
                <h2 className="font-display text-4xl font-bold text-white">{currentPlayer}</h2>
              </div>

              <motion.button
                onClick={advanceReveal}
                whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}
                className="flex items-center gap-2 rounded-2xl px-8 py-4 text-white font-semibold mx-auto"
                style={{ background: "linear-gradient(135deg, hsl(220 35% 24%), hsl(220 35% 18%))", border: "1px solid hsl(220 25% 35%)" }}
              >
                <Eye className="h-5 w-5 text-white/50" />
                Voir mon rôle
              </motion.button>

              {/* Screen privacy hint */}
              <p className="text-white/20 text-xs">Cache l'écran aux autres participants</p>
            </motion.div>
          ) : (
            /* Role reveal */
            <motion.div key="role" initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 1.05 }}
              className="space-y-6 max-w-xs w-full"
            >
              {role ? (
                <>
                  <div className="rounded-3xl border border-white/10 bg-white/5 backdrop-blur p-8 space-y-4">
                    <div className="text-6xl">{role.icon}</div>
                    <div>
                      <p className="text-white/40 text-xs uppercase tracking-wider mb-1">Ton rôle secret</p>
                      <h2 className="font-display text-3xl font-bold text-white">{role.name}</h2>
                    </div>
                    <div className="rounded-xl bg-primary/15 px-4 py-2 inline-block">
                      <p className="text-primary text-sm font-semibold">{role.power}</p>
                    </div>
                    <p className="text-white/50 text-sm leading-relaxed">{role.detail}</p>
                  </div>

                  <motion.button
                    onClick={advanceReveal}
                    whileHover={{ scale: 1.03 }} whileTap={{ scale: 0.97 }}
                    className="w-full rounded-xl py-4 font-semibold text-white flex items-center justify-center gap-2"
                    style={{ background: "linear-gradient(135deg, hsl(16 65% 55%), hsl(45 80% 60%))" }}
                  >
                    {isLast ? "Commencer le débat" : "Passer au suivant"}
                    <ChevronRight className="h-4 w-4" />
                  </motion.button>
                </>
              ) : (
                /* No role assigned (more participants than roles) */
                <>
                  <div className="rounded-3xl border border-white/10 bg-white/5 p-8 space-y-3">
                    <div className="text-5xl">🙂</div>
                    <p className="text-white/40 text-xs uppercase tracking-wider">Ton rôle</p>
                    <h2 className="font-display text-2xl font-bold text-white">Participant libre</h2>
                    <p className="text-white/50 text-sm">Pas de rôle spécial pour toi — joue librement !</p>
                  </div>
                  <motion.button onClick={advanceReveal}
                    whileHover={{ scale: 1.03 }} whileTap={{ scale: 0.97 }}
                    className="w-full rounded-xl py-4 font-semibold text-white flex items-center justify-center gap-2"
                    style={{ background: "linear-gradient(135deg, hsl(16 65% 55%), hsl(45 80% 60%))" }}
                  >
                    {isLast ? "Commencer le débat" : "Passer au suivant"}
                    <ChevronRight className="h-4 w-4" />
                  </motion.button>
                </>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    );
  }

  // ── VOTE ─────────────────────────────────────────────────────────────────
  if (phase === "vote") {
    const voter = participants[voteIndex];
    const choices = participants.filter((p) => p !== voter);

    return (
      <motion.div
        key={`vote-${voteIndex}-${voteRevealed}`}
        initial={{ opacity: 0 }} animate={{ opacity: 1 }}
        className="min-h-screen flex flex-col items-center justify-center px-6 text-center"
        style={{ background: BG }}
      >
        <AnimatePresence mode="wait">
          {!voteRevealed ? (
            <motion.div key="handoff" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }}
              className="space-y-8 max-w-xs"
            >
              <div>
                <p className="text-white/30 text-sm mb-3">{voteIndex + 1} / {participants.length}</p>
                <p className="text-white/50 text-base mb-2">Passe l'appareil à</p>
                <h2 className="font-display text-4xl font-bold text-white">{voter}</h2>
              </div>
              <motion.button onClick={() => setVoteRevealed(true)}
                whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}
                className="flex items-center gap-2 rounded-2xl px-8 py-4 text-white font-semibold mx-auto"
                style={{ background: "linear-gradient(135deg, hsl(220 35% 24%), hsl(220 35% 18%))", border: "1px solid hsl(220 25% 35%)" }}
              >
                <Trophy className="h-5 w-5 text-white/50" />
                Voter
              </motion.button>
              <p className="text-white/20 text-xs">Cache l'écran aux autres participants</p>
            </motion.div>
          ) : (
            <motion.div key="vote-screen" initial={{ opacity: 0, scale: 0.92 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0 }}
              className="space-y-6 max-w-sm w-full"
            >
              <div>
                <p className="text-white/40 text-xs uppercase tracking-widest mb-2">Vote de {voter}</p>
                <h2 className="font-display text-2xl font-bold text-white">Qui a été le plus convaincant ?</h2>
              </div>

              <div className="grid gap-3" style={{ gridTemplateColumns: choices.length <= 3 ? "1fr" : "1fr 1fr" }}>
                {choices.map((p) => {
                  const isSelected = selectedVote === p;
                  return (
                    <motion.button key={p} onClick={() => setSelectedVote(p)}
                      whileHover={{ scale: 1.03 }} whileTap={{ scale: 0.97 }}
                      className="flex items-center gap-3 rounded-2xl px-5 py-4 text-left transition-all"
                      style={{
                        background: isSelected ? "linear-gradient(135deg, hsl(16 65% 55% / 0.2), hsl(45 80% 60% / 0.15))" : "hsl(220 30% 18%)",
                        border: isSelected ? "2px solid hsl(16 65% 55%)" : "1px solid hsl(220 25% 28%)",
                        boxShadow: isSelected ? "0 0 20px hsl(16 65% 55% / 0.25)" : "none",
                      }}
                    >
                      <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full font-bold text-white"
                        style={{ background: isSelected ? "linear-gradient(135deg, hsl(16 65% 55%), hsl(45 80% 60%))" : "hsl(220 30% 26%)", fontSize: 16 }}>
                        {p[0]?.toUpperCase()}
                      </div>
                      <span className={`font-semibold ${isSelected ? "text-white" : "text-white/70"}`}>{p}</span>
                      {isSelected && <span className="ml-auto text-lg">✓</span>}
                    </motion.button>
                  );
                })}
              </div>

              <motion.button onClick={confirmVote} disabled={!selectedVote}
                whileHover={{ scale: selectedVote ? 1.02 : 1 }} whileTap={{ scale: 0.97 }}
                className="w-full rounded-xl py-4 font-semibold text-white flex items-center justify-center gap-2 transition-opacity disabled:opacity-30"
                style={{ background: "linear-gradient(135deg, hsl(16 65% 55%), hsl(45 80% 60%))" }}
              >
                {voteIndex + 1 === participants.length ? "Voir les résultats" : "Confirmer"}
                <ChevronRight className="h-4 w-4" />
              </motion.button>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    );
  }

  // ── RESULTS ───────────────────────────────────────────────────────────────
  if (phase === "results") {
    const ranked = [...participants].sort((a, b) => (votes[b] ?? 0) - (votes[a] ?? 0));
    const medals = ["🥇", "🥈", "🥉"];
    const maxVotes = votes[ranked[0]] ?? 0;

    return (
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}
        className="min-h-screen flex flex-col items-center justify-center px-6 py-12"
        style={{ background: BG }}
      >
        <div className="w-full max-w-sm space-y-6">
          <div className="text-center">
            <p className="text-4xl mb-3">🏆</p>
            <h2 className="font-display text-3xl font-bold text-white">Résultats</h2>
            <p className="text-white/40 text-sm mt-1">{debate.title}</p>
          </div>

          <ul className="space-y-3">
            {ranked.map((p, i) => {
              const v = votes[p] ?? 0;
              const pct = maxVotes > 0 ? (v / maxVotes) * 100 : 0;
              const isWinner = i === 0 && v > 0;
              return (
                <motion.li key={p}
                  initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.1 }}
                  className="rounded-2xl p-4 space-y-2"
                  style={{
                    background: isWinner ? "linear-gradient(135deg, hsl(45 80% 60% / 0.15), hsl(16 65% 55% / 0.1))" : "hsl(220 30% 16%)",
                    border: isWinner ? "1px solid hsl(45 80% 60% / 0.4)" : "1px solid hsl(220 25% 25%)",
                  }}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <span className="text-xl">{medals[i] ?? `${i + 1}.`}</span>
                      <div className="flex h-9 w-9 items-center justify-center rounded-full font-bold text-white"
                        style={{ background: isWinner ? "linear-gradient(135deg, hsl(16 65% 55%), hsl(45 80% 60%))" : "hsl(220 30% 26%)", fontSize: 14 }}>
                        {p[0]?.toUpperCase()}
                      </div>
                      <span className={`font-semibold ${isWinner ? "text-white" : "text-white/70"}`}>{p}</span>
                    </div>
                    <span className={`font-display text-lg font-bold tabular-nums ${isWinner ? "text-[hsl(45_80%_65%)]" : "text-white/40"}`}>
                      {v} vote{v !== 1 ? "s" : ""}
                    </span>
                  </div>
                  {maxVotes > 0 && (
                    <div className="h-1.5 rounded-full overflow-hidden" style={{ background: "hsl(220 30% 22%)" }}>
                      <motion.div className="h-full rounded-full"
                        initial={{ width: 0 }}
                        animate={{ width: `${pct}%` }}
                        transition={{ delay: i * 0.1 + 0.3, duration: 0.6, ease: "easeOut" }}
                        style={{ background: isWinner ? "linear-gradient(90deg, hsl(16 65% 55%), hsl(45 80% 60%))" : "hsl(220 25% 35%)" }}
                      />
                    </div>
                  )}
                </motion.li>
              );
            })}
          </ul>

          {maxVotes === 0 && (
            <p className="text-center text-white/30 text-sm">Aucun vote exprimé</p>
          )}

          <motion.button onClick={() => navigate("/")}
            whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.97 }}
            className="w-full rounded-xl py-4 font-semibold text-white"
            style={{ background: "linear-gradient(135deg, hsl(16 65% 55%), hsl(45 80% 60%))" }}
          >
            Retour à l'accueil
          </motion.button>
        </div>
      </motion.div>
    );
  }

  // ── DEBATE ───────────────────────────────────────────────────────────────
  const n = participants.length;
  const center = tableSize / 2;
  const tableR = tableSize * 0.27;
  const orbitR = tableSize * 0.42;
  const avatarSize = Math.max(48, Math.min(64, tableSize / 7));
  const isLowTime = timeLeft <= 10 && timeLeft > 0;

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}
      className="min-h-screen flex flex-col select-none"
      style={{ background: "radial-gradient(ellipse at 50% 110%, hsl(220 35% 16%), hsl(220 45% 5%))" }}
    >
      {/* Top bar */}
      <div className="flex items-start justify-between px-5 pt-5 pb-2">
        <button onClick={() => navigate("/debates")}
          className="flex items-center gap-1.5 text-sm text-white/30 hover:text-white/60 transition-colors">
          <ArrowLeft className="h-4 w-4" /> Quitter
        </button>
        <div className="text-center max-w-xs">
          <p className="text-[10px] uppercase tracking-widest text-white/25">{FORMAT_LABELS[debate.format]}</p>
          <h1 className="font-display text-sm font-semibold text-white/70 mt-0.5 leading-snug line-clamp-2">{debate.title}</h1>
        </div>
        <div className="w-16" />
      </div>

      {/* Round table */}
      <div className="flex-1 flex items-center justify-center">
        <div ref={containerRef} className="relative" style={{ width: tableSize, height: tableSize }}>

          {/* Table surface */}
          <div className="absolute rounded-full" style={{
            width: tableR * 2, height: tableR * 2,
            top: center - tableR, left: center - tableR,
            background: "radial-gradient(circle at 40% 35%, hsl(220 30% 22%), hsl(220 40% 13%))",
            border: "1px solid hsl(220 25% 32%)",
            boxShadow: "0 0 80px hsl(220 40% 5%), 0 0 0 1px hsl(220 25% 28% / 0.5), inset 0 1px 0 hsl(220 20% 38% / 0.3)",
          }} />

          {/* Timer ring */}
          <div className="absolute" style={{ width: tableR * 2, height: tableR * 2, top: center - tableR, left: center - tableR }}>
            <TimerRing value={timeLeft} max={speakingTime} size={tableR * 2} />
          </div>

          {/* Center */}
          <div className="absolute flex flex-col items-center justify-center"
            style={{ top: center - tableR, left: center - tableR, width: tableR * 2, height: tableR * 2 }}>
            <motion.span
              className="font-display font-bold tabular-nums"
              style={{ fontSize: tableR * 0.48, color: isLowTime ? "hsl(0 72% 51%)" : "hsl(36 33% 97%)" }}
              animate={isLowTime ? { scale: [1, 1.04, 1] } : {}}
              transition={{ duration: 0.5, repeat: isLowTime ? Infinity : 0 }}
            >
              {formatTime(timeLeft)}
            </motion.span>
            <p className="text-white/40 font-medium" style={{ fontSize: tableR * 0.13 }}>
              {participants[currentSpeaker]}
            </p>
            <motion.button onClick={() => setIsRunning((r) => !r)}
              whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.92 }}
              className="mt-3 flex items-center justify-center rounded-full transition-all"
              style={{
                width: tableR * 0.38, height: tableR * 0.38,
                background: isRunning ? "hsl(220 30% 26%)" : "linear-gradient(135deg, hsl(16 65% 55%), hsl(45 80% 60%))",
                boxShadow: isRunning ? "none" : "0 4px 20px hsl(16 65% 55% / 0.4)",
              }}>
              {isRunning
                ? <Pause style={{ width: tableR * 0.16, height: tableR * 0.16, color: "white" }} />
                : <Play style={{ width: tableR * 0.16, height: tableR * 0.16, color: "white", marginLeft: "2px" }} />}
            </motion.button>
          </div>

          {/* Participants */}
          {participants.map((p, i) => {
            const angle = (2 * Math.PI * i) / n - Math.PI / 2;
            const x = center + orbitR * Math.cos(angle);
            const y = center + orbitR * Math.sin(angle);
            const isActive = i === currentSpeaker;
            const budgetUsed = budgets[p] ?? 0;
            const roleId = assignedRoles[p];
            const role = DEBATE_ROLES.find((r) => r.id === roleId);

            return (
              <motion.button key={p}
                onClick={() => { setCurrentSpeaker(i); setTimeLeft(speakingTime); setIsRunning(false); }}
                style={{ position: "absolute", left: x - avatarSize / 2, top: y - avatarSize / 2, width: avatarSize, height: avatarSize }}
                whileHover={{ scale: 1.12 }} whileTap={{ scale: 0.94 }}
              >
                {isActive && (
                  <motion.div className="absolute inset-0 rounded-full"
                    style={{ background: "hsl(16 65% 55% / 0.35)", filter: "blur(10px)", zIndex: -1 }}
                    animate={{ scale: [1, 1.5, 1] }}
                    transition={{ duration: 2.5, repeat: Infinity, ease: "easeInOut" }}
                  />
                )}
                {maxPerPerson > 0 && <BudgetArc used={budgetUsed} max={maxPerPerson} size={avatarSize} />}
                <div className="absolute inset-0 rounded-full flex items-center justify-center font-bold text-white transition-all"
                  style={{
                    margin: maxPerPerson > 0 ? 4 : 0,
                    fontSize: avatarSize * 0.32,
                    background: isActive ? "linear-gradient(135deg, hsl(16 65% 55%), hsl(45 80% 60%))" : "hsl(220 30% 22%)",
                    border: isActive ? "2px solid hsl(16 65% 65%)" : "1px solid hsl(220 25% 32%)",
                    boxShadow: isActive ? "0 0 0 3px hsl(16 65% 55% / 0.3)" : "none",
                  }}>
                  {p[0]?.toUpperCase()}
                </div>
                <div className="absolute text-center whitespace-nowrap font-medium"
                  style={{ fontSize: 11, top: avatarSize + 4, left: "50%", transform: "translateX(-50%)", color: isActive ? "hsl(16 65% 70%)" : "hsl(220 15% 55%)" }}>
                  {p}
                  {role && <span className="block" style={{ fontSize: 12 }}>{role.icon}</span>}
                </div>
              </motion.button>
            );
          })}
        </div>
      </div>

      {/* Bottom controls */}
      <div className="flex items-center justify-center gap-3 px-6 pb-8 pt-2">
        <motion.button whileHover={{ scale: 1.08 }} whileTap={{ scale: 0.92 }}
          onClick={() => { setTimeLeft(speakingTime); setIsRunning(false); }}
          className="flex h-11 w-11 items-center justify-center rounded-full transition-colors"
          style={{ background: "hsl(220 30% 18%)", color: "hsl(220 15% 55%)" }} title="Réinitialiser">
          <RotateCcw className="h-4 w-4" />
        </motion.button>

        <motion.button whileHover={{ scale: 1.04 }} whileTap={{ scale: 0.96 }}
          onClick={nextSpeaker}
          className="flex items-center gap-2 rounded-full px-6 py-3 text-sm font-semibold text-white transition-all"
          style={{ background: "hsl(220 30% 20%)", border: "1px solid hsl(220 25% 30%)" }}>
          Suivant <SkipForward className="h-4 w-4" />
        </motion.button>

        <motion.button whileHover={{ scale: 1.08 }} whileTap={{ scale: 0.92 }}
          onClick={() => {
            const other = participants.filter((_, i) => i !== currentSpeaker);
            const idx = participants.indexOf(other[Math.floor(Math.random() * other.length)]);
            setCurrentSpeaker(idx); setTimeLeft(speakingTime); setIsRunning(false);
          }}
          className="flex h-11 w-11 items-center justify-center rounded-full transition-colors"
          style={{ background: "hsl(220 30% 18%)", color: "hsl(220 15% 55%)" }} title="Aléatoire">
          <Shuffle className="h-4 w-4" />
        </motion.button>

        <motion.button whileHover={{ scale: 1.08 }} whileTap={{ scale: 0.92 }}
          onClick={endDebate}
          className="flex h-11 w-11 items-center justify-center rounded-full transition-colors"
          style={{ background: "hsl(0 60% 28%)", color: "hsl(0 72% 70%)" }} title="Terminer le débat">
          <Flag className="h-4 w-4" />
        </motion.button>
      </div>
    </motion.div>
  );
}
