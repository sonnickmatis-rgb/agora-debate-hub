import { useState, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import Navbar from "@/components/Navbar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Brain, Plus, Trash2, Eye, EyeOff, CheckCircle2, RotateCcw, Trophy, Users, ShieldQuestion } from "lucide-react";

type Phase = "setup" | "handoff" | "writing" | "guessing" | "reveal" | "scoreboard";

interface Player {
  id: string;
  name: string;
  score: number;
}

interface Round {
  writerIndex: number;
  phrase: string;
  guesses: Record<string, string>; // guesserId -> guessedPlayerId
}

export default function MindGamePage() {
  const [phase, setPhase] = useState<Phase>("setup");
  const [players, setPlayers] = useState<Player[]>([]);
  const [newName, setNewName] = useState("");
  const [currentRound, setCurrentRound] = useState<Round | null>(null);
  const [roundIndex, setRoundIndex] = useState(0);
  const [phraseInput, setPhraseInput] = useState("");
  const [showPhrase, setShowPhrase] = useState(false);
  const [currentGuesserIdx, setCurrentGuesserIdx] = useState(0);
  const [rounds, setRounds] = useState<Round[]>([]);

  // Setup
  const addPlayer = () => {
    const name = newName.trim();
    if (!name || players.length >= 8 || players.some((p) => p.name === name)) return;
    setPlayers((prev) => [...prev, { id: crypto.randomUUID(), name, score: 0 }]);
    setNewName("");
  };

  const removePlayer = (id: string) => setPlayers((prev) => prev.filter((p) => p.id !== id));

  const canStart = players.length >= 4;

  const startGame = () => {
    setRoundIndex(0);
    setRounds([]);
    setPhase("writing");
    startWritingPhase(0);
  };

  // Writing phase — start with anonymous handoff screen
  const startWritingPhase = (writerIdx: number) => {
    setCurrentRound({ writerIndex: writerIdx, phrase: "", guesses: {} });
    setPhraseInput("");
    setShowPhrase(false);
    setPhase("handoff");
  };

  const confirmHandoff = () => {
    setPhase("writing");
  };

  const submitPhrase = () => {
    if (!phraseInput.trim() || !currentRound) return;
    setCurrentRound({ ...currentRound, phrase: phraseInput.trim() });
    // Move to guessing
    const guessers = players.filter((_, i) => i !== currentRound.writerIndex);
    setCurrentGuesserIdx(0);
    setPhase("guessing");
  };

  // Guessing phase
  const getGuessers = useCallback(() => {
    if (!currentRound) return [];
    return players.filter((_, i) => i !== currentRound.writerIndex);
  }, [currentRound, players]);

  const submitGuess = (guessedPlayerId: string) => {
    if (!currentRound) return;
    const guessers = getGuessers();
    const guesser = guessers[currentGuesserIdx];

    const updatedGuesses = { ...currentRound.guesses, [guesser.id]: guessedPlayerId };
    const updatedRound = { ...currentRound, guesses: updatedGuesses };
    setCurrentRound(updatedRound);

    if (currentGuesserIdx < guessers.length - 1) {
      setCurrentGuesserIdx(currentGuesserIdx + 1);
    } else {
      // All guesses in — reveal
      // Calculate scores
      const writer = players[updatedRound.writerIndex];
      const newPlayers = players.map((p) => {
        if (updatedGuesses[p.id] === writer.id) {
          return { ...p, score: p.score + 1 };
        }
        return p;
      });
      // Bonus for writer if nobody guessed
      const nobodyGuessed = !Object.values(updatedGuesses).some((g) => g === writer.id);
      if (nobodyGuessed) {
        const writerPlayer = newPlayers.find((p) => p.id === writer.id);
        if (writerPlayer) writerPlayer.score += 2;
      }
      setPlayers(newPlayers);
      setRounds((prev) => [...prev, updatedRound]);
      setPhase("reveal");
    }
  };

  const nextRound = () => {
    const next = roundIndex + 1;
    if (next >= players.length) {
      setPhase("scoreboard");
    } else {
      setRoundIndex(next);
      startWritingPhase(next);
    }
  };

  const resetGame = () => {
    setPhase("setup");
    setPlayers((prev) => prev.map((p) => ({ ...p, score: 0 })));
    setRounds([]);
    setRoundIndex(0);
    setCurrentRound(null);
  };

  const writer = currentRound ? players[currentRound.writerIndex] : null;
  const guessers = getGuessers();
  const currentGuesser = guessers[currentGuesserIdx];

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="container mx-auto max-w-2xl px-4 py-12">
        {/* Header */}
        <div className="mb-8 flex items-center gap-3">
          <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-secondary text-secondary-foreground">
            <Brain className="h-6 w-6" />
          </div>
          <div>
            <h1 className="font-display text-3xl font-bold text-foreground">Mind</h1>
            <p className="text-sm text-muted-foreground">Devinez qui a écrit la phrase mystère</p>
          </div>
        </div>

        <AnimatePresence mode="wait">
          {/* ===== SETUP ===== */}
          {phase === "setup" && (
            <motion.div key="setup" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}>
              <div className="rounded-xl border border-border bg-card p-6 shadow-card">
                <div className="mb-4 flex items-center justify-between">
                  <Label className="text-lg font-semibold">Joueurs ({players.length}/8)</Label>
                  <Badge variant="outline" className={canStart ? "border-olive text-olive" : "border-muted-foreground text-muted-foreground"}>
                    {canStart ? "Prêt !" : `Min. 4 joueurs`}
                  </Badge>
                </div>

                <div className="mb-4 flex gap-2">
                  <Input
                    value={newName}
                    onChange={(e) => setNewName(e.target.value)}
                    onKeyDown={(e) => e.key === "Enter" && addPlayer()}
                    placeholder="Nom du joueur..."
                    className="flex-1"
                    maxLength={20}
                  />
                  <Button onClick={addPlayer} variant="outline" size="icon" disabled={players.length >= 8}>
                    <Plus className="h-4 w-4" />
                  </Button>
                </div>

                <div className="mb-6 space-y-2">
                  {players.map((p, i) => (
                    <motion.div
                      key={p.id}
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      className="flex items-center justify-between rounded-lg border border-border bg-background px-4 py-2"
                    >
                      <div className="flex items-center gap-3">
                        <span className="flex h-7 w-7 items-center justify-center rounded-full bg-primary/10 text-xs font-bold text-primary">
                          {i + 1}
                        </span>
                        <span className="font-medium text-card-foreground">{p.name}</span>
                      </div>
                      <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-destructive" onClick={() => removePlayer(p.id)}>
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </motion.div>
                  ))}
                  {players.length === 0 && (
                    <p className="py-6 text-center text-sm text-muted-foreground">Ajoutez au moins 4 joueurs pour commencer</p>
                  )}
                </div>

                <Button onClick={startGame} disabled={!canStart} variant="hero" size="xl" className="w-full">
                  <Brain className="h-5 w-5" />
                  Lancer la partie
                </Button>

                <div className="mt-4 rounded-lg bg-muted/50 p-4">
                  <h3 className="mb-2 text-sm font-semibold text-foreground">📖 Règles du jeu</h3>
                  <ul className="space-y-1 text-xs text-muted-foreground">
                    <li>• Chaque joueur écrit une phrase anonymement à tour de rôle</li>
                    <li>• Les autres joueurs doivent deviner qui l'a écrite</li>
                    <li>• +1 point pour chaque bonne réponse</li>
                    <li>• +2 points pour l'auteur si personne ne devine</li>
                  </ul>
                </div>
              </div>
            </motion.div>
          )}

          {/* ===== HANDOFF (anonymous) ===== */}
          {phase === "handoff" && (
            <motion.div key="handoff" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}>
              <div className="rounded-xl border border-border bg-card p-8 shadow-card text-center">
                <ShieldQuestion className="mx-auto mb-4 h-12 w-12 text-primary" />
                <Badge variant="outline" className="mb-4">Tour {roundIndex + 1}/{players.length}</Badge>
                <h2 className="font-display text-2xl font-bold text-foreground mb-3">
                  Un joueur doit écrire une phrase secrète
                </h2>
                <p className="text-muted-foreground mb-6">
                  Passez le téléphone discrètement. Les autres joueurs, fermez les yeux !
                </p>
                <Button onClick={confirmHandoff} variant="hero" size="xl" className="w-full">
                  Je suis prêt(e) à écrire
                </Button>
              </div>
            </motion.div>
          )}

          {/* ===== WRITING ===== */}
          {phase === "writing" && currentRound && (
            <motion.div key="writing" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}>
              <div className="rounded-xl border border-border bg-card p-6 shadow-card">
                <div className="mb-2 text-center">
                  <Badge variant="outline" className="mb-4">Tour {roundIndex + 1}/{players.length}</Badge>
                  <h2 className="font-display text-xl font-bold text-foreground">
                    Écrivez votre phrase secrète
                  </h2>
                  <p className="mt-2 text-sm text-muted-foreground">
                    Personne ne doit savoir que c'est vous !
                  </p>
                </div>

                <div className="my-6 space-y-3">
                  <Label htmlFor="phrase">Votre phrase secrète</Label>
                  <div className="relative">
                    <Input
                      id="phrase"
                      type={showPhrase ? "text" : "password"}
                      value={phraseInput}
                      onChange={(e) => setPhraseInput(e.target.value)}
                      placeholder="Écrivez quelque chose que les autres doivent deviner..."
                      className="pr-10"
                      maxLength={200}
                      onKeyDown={(e) => e.key === "Enter" && submitPhrase()}
                    />
                    <button
                      type="button"
                      className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                      onClick={() => setShowPhrase(!showPhrase)}
                    >
                      {showPhrase ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>
                </div>

                <Button onClick={submitPhrase} disabled={!phraseInput.trim()} variant="hero" size="xl" className="w-full">
                  Valider et passer aux devinettes
                </Button>
              </div>
            </motion.div>
          )}

          {/* ===== GUESSING ===== */}
          {phase === "guessing" && currentRound && currentGuesser && (
            <motion.div key={`guessing-${currentGuesserIdx}`} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}>
              <div className="rounded-xl border border-border bg-card p-6 shadow-card">
                <div className="mb-2 text-center">
                  <Badge variant="outline" className="mb-4">Tour {roundIndex + 1}/{players.length}</Badge>
                  <h2 className="mb-1 font-display text-xl font-bold text-foreground">
                    C'est au tour de <span className="text-primary">{currentGuesser.name}</span>
                  </h2>
                  <p className="text-sm text-muted-foreground mb-4">Devinette {currentGuesserIdx + 1}/{guessers.length}</p>
                </div>

                <div className="my-6 rounded-lg bg-secondary/10 border border-secondary/20 p-5 text-center">
                  <p className="text-xs uppercase tracking-wide text-muted-foreground mb-2">La phrase mystère</p>
                  <p className="font-display text-lg font-semibold text-foreground italic">« {currentRound.phrase} »</p>
                </div>

                <p className="mb-3 text-center text-sm font-medium text-foreground">Qui a écrit cette phrase ?</p>
                <div className="grid gap-2 sm:grid-cols-2">
                  {players
                    .filter((p) => p.id !== currentGuesser.id)
                    .map((p) => (
                      <Button
                        key={p.id}
                        variant="outline"
                        className="justify-start gap-2 h-12 text-left"
                        onClick={() => submitGuess(p.id)}
                      >
                        <Users className="h-4 w-4 text-muted-foreground" />
                        {p.name}
                      </Button>
                    ))}
                </div>
              </div>
            </motion.div>
          )}

          {/* ===== REVEAL ===== */}
          {phase === "reveal" && currentRound && writer && (
            <motion.div key="reveal" initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0 }}>
              <div className="rounded-xl border border-border bg-card p-6 shadow-card">
                <div className="text-center mb-6">
                  <h2 className="font-display text-2xl font-bold text-foreground mb-2">Résultat du tour</h2>
                  <div className="rounded-lg bg-secondary/10 border border-secondary/20 p-4 mb-4">
                    <p className="text-xs uppercase tracking-wide text-muted-foreground mb-1">La phrase était de</p>
                    <p className="font-display text-xl font-bold text-primary">{writer.name}</p>
                    <p className="mt-2 italic text-muted-foreground">« {currentRound.phrase} »</p>
                  </div>
                </div>

                <div className="space-y-2 mb-6">
                  {guessers.map((guesser) => {
                    const guessedId = currentRound.guesses[guesser.id];
                    const guessedPlayer = players.find((p) => p.id === guessedId);
                    const correct = guessedId === writer.id;
                    return (
                      <div key={guesser.id} className={`flex items-center justify-between rounded-lg border px-4 py-3 ${correct ? "border-olive bg-olive/5" : "border-border bg-background"}`}>
                        <span className="font-medium text-card-foreground">{guesser.name}</span>
                        <div className="flex items-center gap-2">
                          <span className="text-sm text-muted-foreground">→ {guessedPlayer?.name}</span>
                          {correct ? (
                            <CheckCircle2 className="h-5 w-5 text-olive" />
                          ) : (
                            <span className="text-sm text-destructive">✗</span>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>

                <Button onClick={nextRound} variant="hero" size="xl" className="w-full">
                  {roundIndex + 1 >= players.length ? "Voir les scores finaux" : "Tour suivant"}
                </Button>
              </div>
            </motion.div>
          )}

          {/* ===== SCOREBOARD ===== */}
          {phase === "scoreboard" && (
            <motion.div key="scoreboard" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
              <div className="rounded-xl border border-border bg-card p-6 shadow-card">
                <div className="text-center mb-6">
                  <Trophy className="mx-auto mb-2 h-10 w-10 text-gold" />
                  <h2 className="font-display text-2xl font-bold text-foreground">Classement final</h2>
                </div>

                <div className="space-y-2 mb-6">
                  {[...players]
                    .sort((a, b) => b.score - a.score)
                    .map((p, i) => (
                      <div key={p.id} className={`flex items-center justify-between rounded-lg border px-4 py-3 ${i === 0 ? "border-gold bg-gold/5 shadow-warm" : "border-border bg-background"}`}>
                        <div className="flex items-center gap-3">
                          <span className={`flex h-8 w-8 items-center justify-center rounded-full text-sm font-bold ${i === 0 ? "bg-gold/20 text-gold" : i === 1 ? "bg-muted text-muted-foreground" : "bg-muted/50 text-muted-foreground"}`}>
                            {i === 0 ? "🥇" : i === 1 ? "🥈" : i === 2 ? "🥉" : i + 1}
                          </span>
                          <span className="font-semibold text-card-foreground">{p.name}</span>
                        </div>
                        <span className="font-display text-lg font-bold text-primary">{p.score} pt{p.score > 1 ? "s" : ""}</span>
                      </div>
                    ))}
                </div>

                <Button onClick={resetGame} variant="outline" size="xl" className="w-full">
                  <RotateCcw className="h-4 w-4" />
                  Nouvelle partie
                </Button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
