import { useState, createContext, useContext, ReactNode } from "react";
import { Debate, GameType } from "@/types/debate";

interface DebateContextType {
  debates: Debate[];
  addDebate: (debate: Omit<Debate, "id" | "createdAt" | "status" | "participants">) => string;
  activeDebate: Debate | null;
  setActiveDebate: (id: string | null) => void;
  updateDebateStatus: (id: string, status: Debate["status"]) => void;
}

const DebateContext = createContext<DebateContextType | null>(null);

const SAMPLE_DEBATES: Debate[] = [
  {
    id: "1",
    title: "L'IA remplacera-t-elle les enseignants ?",
    description: "Un débat sur l'avenir de l'éducation face à l'intelligence artificielle.",
    format: "oxford",
    speakingTime: 120,
    maxParticipants: 6,
    status: "active",
    participants: ["Alice", "Bob", "Clara", "David"],
    createdAt: new Date("2026-02-28"),
    rules: ["Pas d'interruption", "Arguments sourcés"],
    games: ["vote-rapide", "quiz"],
    roles: ["avocat", "imposteur"],
    category: "technologie",
  },
  {
    id: "2",
    title: "Faut-il limiter les réseaux sociaux pour les mineurs ?",
    description: "Discussion autour de la régulation des plateformes numériques.",
    format: "table-ronde",
    speakingTime: 90,
    maxParticipants: 8,
    status: "draft",
    participants: ["Emma", "Félix"],
    createdAt: new Date("2026-03-01"),
    rules: ["Respecter le temps de parole"],
    games: ["avocat-du-diable"],
    roles: [],
    category: "societe",
  },
  {
    id: "3",
    title: "Le nucléaire est-il indispensable pour la transition énergétique ?",
    description: "Débat scientifique et politique sur les choix énergétiques.",
    format: "lincoln-douglas",
    speakingTime: 180,
    maxParticipants: 4,
    status: "completed",
    participants: ["Hugo", "Iris", "Jules", "Karine"],
    createdAt: new Date("2026-02-25"),
    rules: ["Un argument par tour", "Réfutation obligatoire"],
    games: ["mot-interdit", "vote-rapide"],
    roles: ["arbitre", "chroniqueur"],
    category: "environnement",
  },
];

export function DebateProvider({ children }: { children: ReactNode }) {
  const [debates, setDebates] = useState<Debate[]>(SAMPLE_DEBATES);
  const [activeDebateId, setActiveDebateId] = useState<string | null>(null);

  const addDebate = (debate: Omit<Debate, "id" | "createdAt" | "status" | "participants">): string => {
    const id = crypto.randomUUID();
    const newDebate: Debate = {
      ...debate,
      id,
      createdAt: new Date(),
      status: "draft",
      participants: [],
    };
    setDebates((prev) => [newDebate, ...prev]);
    return id;
  };

  const activeDebate = debates.find((d) => d.id === activeDebateId) ?? null;

  const setActiveDebate = (id: string | null) => setActiveDebateId(id);

  const updateDebateStatus = (id: string, status: Debate["status"]) => {
    setDebates((prev) => prev.map((d) => (d.id === id ? { ...d, status } : d)));
  };

  return (
    <DebateContext.Provider value={{ debates, addDebate, activeDebate, setActiveDebate, updateDebateStatus }}>
      {children}
    </DebateContext.Provider>
  );
}

export function useDebates() {
  const ctx = useContext(DebateContext);
  if (!ctx) throw new Error("useDebates must be used within DebateProvider");
  return ctx;
}
