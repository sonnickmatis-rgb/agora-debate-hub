import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { DebateProvider } from "@/context/DebateContext";
import Index from "./pages/Index";
import DebateListPage from "./pages/DebateListPage";
import CreateDebatePage from "./pages/CreateDebatePage";
import DebateSessionPage from "./pages/DebateSessionPage";
import MindGamePage from "./pages/MindGamePage";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <DebateProvider>
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<Index />} />
            <Route path="/debates" element={<DebateListPage />} />
            <Route path="/debates/new" element={<CreateDebatePage />} />
            <Route path="/debates/:id" element={<DebateSessionPage />} />
            <Route path="/mind" element={<MindGamePage />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </DebateProvider>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
