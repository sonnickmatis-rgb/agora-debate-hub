export interface Debate {
  id: string;
  title: string;
  description: string;
  category?: string;
  format: "oxford" | "lincoln-douglas" | "table-ronde" | "libre";
  speakingTime: number;
  maxParticipants: number;
  status: "draft" | "active" | "completed";
  participants: string[];
  createdAt: Date;
  rules: string[];
  selectedRules?: string[];
  games: GameType[];
  roles: string[];
  maxTimePerPerson?: number;
}

// ── CATEGORIES ──────────────────────────────────────────────────────────────

export interface DebateCategory {
  id: string;
  label: string;
  icon: string;
}

export const DEBATE_CATEGORIES: DebateCategory[] = [
  { id: "politique",    label: "Politique",    icon: "🏛️" },
  { id: "societe",      label: "Société",      icon: "🌍" },
  { id: "technologie",  label: "Technologie",  icon: "💻" },
  { id: "environnement",label: "Environnement",icon: "🌿" },
  { id: "economie",     label: "Économie",     icon: "💰" },
  { id: "ethique",      label: "Éthique",      icon: "⚖️" },
  { id: "sante",        label: "Santé",        icon: "⚕️" },
  { id: "education",    label: "Éducation",    icon: "📚" },
  { id: "culture",      label: "Culture",      icon: "🎭" },
  { id: "sciences",     label: "Sciences",     icon: "🔬" },
];

// ── SUGGESTED TOPICS ────────────────────────────────────────────────────────

export interface TopicSuggestion {
  topic: string;
  category: string;
}

export const SUGGESTED_TOPICS: TopicSuggestion[] = [
  // Politique
  { topic: "Doit-on rendre le vote obligatoire ?",               category: "politique" },
  { topic: "Faut-il instaurer un gouvernement mondial ?",        category: "politique" },
  { topic: "Les partis politiques sont-ils encore utiles ?",     category: "politique" },
  // Société
  { topic: "Faut-il interdire les réseaux sociaux avant 16 ans ?", category: "societe" },
  { topic: "La semaine de 4 jours doit-elle devenir la norme ?",   category: "societe" },
  { topic: "Les jeux vidéo sont-ils néfastes pour les jeunes ?",   category: "societe" },
  { topic: "Faut-il légaliser toutes les drogues ?",               category: "societe" },
  // Technologie
  { topic: "L'IA va-t-elle remplacer les enseignants ?",         category: "technologie" },
  { topic: "Le télétravail est-il bénéfique pour la société ?",  category: "technologie" },
  { topic: "L'espace : privatiser ou rester étatique ?",         category: "technologie" },
  { topic: "Faut-il réguler les algorithmes des réseaux sociaux ?", category: "technologie" },
  // Environnement
  { topic: "Le nucléaire est-il indispensable à la transition énergétique ?", category: "environnement" },
  { topic: "Peut-on concilier croissance économique et écologie ?",            category: "environnement" },
  { topic: "Faut-il interdire les vols courts en avion ?",                     category: "environnement" },
  // Économie
  { topic: "Devrait-on instaurer un revenu universel de base ?", category: "economie" },
  { topic: "Le capitalisme peut-il être éthique ?",              category: "economie" },
  { topic: "Faut-il taxer davantage les ultra-riches ?",         category: "economie" },
  // Éthique
  { topic: "Les animaux ont-ils les mêmes droits que les humains ?", category: "ethique" },
  { topic: "L'euthanasie doit-elle être légalisée ?",                category: "ethique" },
  { topic: "Peut-on tout pardonner ?",                               category: "ethique" },
  // Santé
  { topic: "La médecine alternative a-t-elle sa place en hôpital ?", category: "sante" },
  { topic: "Faut-il rendre les vaccins obligatoires ?",              category: "sante" },
  // Éducation
  { topic: "Les notes à l'école font-elles plus de mal que de bien ?", category: "education" },
  { topic: "L'université doit-elle être entièrement gratuite ?",       category: "education" },
  // Culture
  { topic: "L'art généré par IA est-il de l'art ?",            category: "culture" },
  { topic: "Le sport de haut niveau est-il trop mercantile ?", category: "culture" },
  // Sciences
  { topic: "Doit-on financer la recherche sur l'immortalité humaine ?", category: "sciences" },
  { topic: "Le clonage humain doit-il être autorisé à des fins médicales ?", category: "sciences" },
];

// ── GAMES ───────────────────────────────────────────────────────────────────

export type GameType =
  | "vote-rapide"
  | "avocat-du-diable"
  | "quiz"
  | "mot-interdit"
  | "chrono-surprise"
  | "rhetorique-inversee"
  | "factcheck"
  | "tour-express"
  | "defi-rheto"
  | "debat-ecrit";

export interface Game {
  type: GameType;
  label: string;
  description: string;
  icon: string;
}

export const GAMES: Game[] = [
  { type: "vote-rapide",         label: "Vote Rapide",          description: "Sondage instantané : l'audience vote pour ou contre",               icon: "⚡" },
  { type: "avocat-du-diable",    label: "Avocat du Diable",     description: "Un participant doit défendre la position opposée à la sienne",      icon: "😈" },
  { type: "quiz",                label: "Quiz Éclair",           description: "Questions rapides sur le sujet, l'audience répond en 10s",          icon: "🧠" },
  { type: "mot-interdit",        label: "Mot Interdit",          description: "Certains mots sont bannis — les utiliser coûte du temps de parole", icon: "🚫" },
  { type: "chrono-surprise",     label: "Chrono Surprise",       description: "Le temps de parole change aléatoirement à chaque tour",             icon: "⏱️" },
  { type: "rhetorique-inversee", label: "Rhétorique Inversée",   description: "À mi-débat, chaque camp doit défendre la position adverse",         icon: "🔄" },
  { type: "factcheck",           label: "Fact-Check Live",       description: "Chaque argument peut être challengé — le groupe vote sa véracité",  icon: "🔍" },
  { type: "tour-express",        label: "Tour Express",          description: "Chaque participant dispose de 30s max — pas d'exception",            icon: "🏃" },
  { type: "defi-rheto",          label: "Défi Rhétorique",       description: "Un participant lance un défi (métaphore, analogie…) à l'adversaire",icon: "🎯" },
  { type: "debat-ecrit",         label: "Débat Écrit",           description: "Les arguments sont écrits puis lus — silence total pendant la saisie", icon: "✍️" },
];

// ── ROLES ────────────────────────────────────────────────────────────────────

export interface DebateRole {
  id: string;
  name: string;
  icon: string;
  power: string;
  detail: string;
}

export const DEBATE_ROLES: DebateRole[] = [
  {
    id: "avocat",
    name: "L'Avocat",
    icon: "🧑‍⚖️",
    power: "+30s de temps de parole",
    detail: "Peut demander une prolongation de 30 secondes une seule fois pendant le débat. Personne ne peut la refuser.",
  },
  {
    id: "president",
    name: "Le Président",
    icon: "👑",
    power: "Redistribue du temps",
    detail: "Peut offrir 20 secondes de son propre temps à n'importe quel autre participant, une fois par débat.",
  },
  {
    id: "imposteur",
    name: "L'Imposteur",
    icon: "🎭",
    power: "Défend secrètement l'adversaire",
    detail: "Son rôle est secret. Il défend en apparence son camp mais sabote discrètement ses arguments. Révélé uniquement à la fin.",
  },
  {
    id: "arbitre",
    name: "L'Arbitre",
    icon: "⚖️",
    power: "Invalide un argument",
    detail: "Peut lever la main une fois pour challenger un argument. Le groupe vote (5s) : si majorité, l'argument est annulé et le temps retranché.",
  },
  {
    id: "provocateur",
    name: "Le Provocateur",
    icon: "😤",
    power: "Interrupt sans pénalité",
    detail: "Peut couper la parole d'un autre participant une fois sans pénalité. L'interrompu reprend son temps là où il en était.",
  },
  {
    id: "analyste",
    name: "L'Analyste",
    icon: "🔎",
    power: "Pose une question à tout moment",
    detail: "Peut interrompre le débat à n'importe quel moment pour poser une question à un participant. Celui-ci doit répondre en 15s.",
  },
  {
    id: "fantome",
    name: "Le Fantôme",
    icon: "👻",
    power: "Revient après son tour",
    detail: "Après avoir pris la parole, peut revenir une seconde fois (20s max) pour ajouter un élément qu'il a oublié — une seule fois par débat.",
  },
  {
    id: "joker",
    name: "Le Joker",
    icon: "🃏",
    power: "Copie le pouvoir d'un autre",
    detail: "Peut activer le pouvoir d'un autre joueur (avec son accord). Utilisable une seule fois, le joueur copié ne peut plus utiliser son pouvoir.",
  },
  {
    id: "muet",
    name: "Le Muet",
    icon: "🤫",
    power: "Communique par écrit uniquement",
    detail: "Ne peut pas parler. Écrit ses arguments sur papier ou tableau. Son silence peut être une arme : tout le monde l'écoute quand il montre.",
  },
  {
    id: "chroniqueur",
    name: "Le Chroniqueur",
    icon: "📝",
    power: "Cite n'importe quel argument passé",
    detail: "Note tous les arguments. Peut à tout moment citer textuellement ce qu'un participant a dit pour le contredire ou le soutenir.",
  },
];

// ── FORMAT ───────────────────────────────────────────────────────────────────

export const FORMAT_LABELS: Record<Debate["format"], string> = {
  oxford: "Oxford",
  "lincoln-douglas": "Lincoln-Douglas",
  "table-ronde": "Table Ronde",
  libre: "Format Libre",
};

export const FORMAT_INFO: Record<Debate["format"], { short: string; detail: string }> = {
  oxford: {
    short: "2 équipes, motion claire, vote de l'audience",
    detail: "Deux équipes s'affrontent sur une motion. L'une propose, l'autre s'oppose. Chaque camp dispose de temps égaux pour argumenter, réfuter et conclure. Vote de l'audience avant et après pour mesurer l'impact rhétorique.",
  },
  "lincoln-douglas": {
    short: "Duel 1 contre 1, sujets éthiques",
    detail: "Débat en duel (1 contre 1). Chaque participant défend une valeur ou un principe moral. Les tours alternent : affirmation, contre-interrogatoire, réfutation. Format idéal pour les sujets éthiques ou philosophiques.",
  },
  "table-ronde": {
    short: "Discussion ouverte, pas d'équipes fixes",
    detail: "Échange ouvert et collaboratif entre plusieurs participants sans équipes figées. Chacun peut changer de position au fil du débat. L'animateur distribue la parole et veille à l'équilibre des interventions.",
  },
  libre: {
    short: "Aucune contrainte, vous définissez les règles",
    detail: "Structure totalement libre. Vous définissez vous-mêmes la dynamique et les contraintes. Idéal pour des sessions informelles, des expérimentations pédagogiques ou des formats hybrides.",
  },
};
